<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class Skillable extends Model
{
    use HasFactory;

    public function skill(): MorphTo
    {
        return $this->morphTo();
    }
}
